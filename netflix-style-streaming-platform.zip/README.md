# StreamFlix — Full-Stack Streaming Platform

A portfolio-ready streaming-catalog demo built with React, Vite, Node.js, Express, and MongoDB.
It includes account registration/login, movie browsing, search, details, and a personal watchlist.
This is an original demo app and does not include copyrighted Netflix assets or licensed video content.

## Features
- Register and log in with JWT authentication
- Browse a seeded catalog of demo titles
- Search titles by name, genre, or description
- View title details and add/remove items from a watchlist
- Responsive UI with loading and error states
- MongoDB persistence, with optional demo in-memory mode for quick local testing

## Requirements
- Node.js 18+
- npm
- MongoDB (optional; if `MONGODB_URI` is omitted, the server uses in-memory demo storage)

## Run locally

### 1. Backend
```bash
cd server
cp .env.example .env
npm install
npm run dev
```
The API starts at `http://localhost:5000`. Set `JWT_SECRET` in `.env` before using real accounts.
If you have MongoDB, set `MONGODB_URI=mongodb://127.0.0.1:27017/streamflix`.

### 2. Frontend
In a second terminal:
```bash
cd client
npm install
npm run dev
```
Open the Vite URL shown in your terminal (usually `http://localhost:5173`).

## Demo mode
Without MongoDB, catalog and account data live in server memory and reset whenever the server restarts.
Use this only for local demos, not production.

## API overview
- `GET /api/health` — health check
- `GET /api/titles?q=` — list/search titles
- `GET /api/titles/:id` — title details
- `POST /api/auth/register` — create account
- `POST /api/auth/login` — log in
- `GET /api/watchlist` — authenticated user's watchlist
- `POST /api/watchlist/:titleId` — add title
- `DELETE /api/watchlist/:titleId` — remove title

## Security notes
- Passwords are hashed with bcrypt.
- JWT secret must be changed for any deployed environment.
- Configure CORS, HTTPS, rate limiting, validation, and a managed database before public deployment.
- Never commit `.env` files or real credentials.
