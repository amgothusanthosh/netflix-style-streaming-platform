import "dotenv/config";
import express from "express";
import cors from "cors";
import mongoose from "mongoose";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import { seedTitles } from "./data.js";
import { User, Title } from "./models.js";

const app = express();
const PORT = process.env.PORT || 5000;
const JWT_SECRET = process.env.JWT_SECRET || "local-demo-secret-change-me";
const mongoEnabled = Boolean(process.env.MONGODB_URI);
app.use(cors({ origin: process.env.CLIENT_ORIGIN || "http://localhost:5173" }));
app.use(express.json({ limit: "1mb" }));

const demoUsers = new Map();
const demoWatchlists = new Map();
let demoTitles = [...seedTitles];

function safeUser(user) {
  return { id: user.id || user._id, name: user.name, email: user.email };
}
function signToken(user) {
  return jwt.sign({ id: String(user.id || user._id), email: user.email }, JWT_SECRET, { expiresIn: "7d" });
}
function auth(req, res, next) {
  const token = req.headers.authorization?.replace(/^Bearer\s+/i, "");
  if (!token) return res.status(401).json({ message: "Please log in first." });
  try { req.user = jwt.verify(token, JWT_SECRET); next(); }
  catch { return res.status(401).json({ message: "Session expired. Please log in again." }); }
}
async function listTitles(q = "") {
  if (mongoEnabled) {
    const filter = q ? { $or: [
      { title: { $regex: q, $options: "i" } },
      { genre: { $regex: q, $options: "i" } },
      { description: { $regex: q, $options: "i" } }
    ] } : {};
    return Title.find(filter).lean();
  }
  const needle = q.toLowerCase();
  return demoTitles.filter(t => !needle || [t.title, t.genre, t.description].some(v => v?.toLowerCase().includes(needle)));
}
async function getUser(id) {
  if (mongoEnabled) return User.findById(id);
  return demoUsers.get(id);
}

app.get("/api/health", (_req, res) => res.json({ status: "ok", database: mongoEnabled ? "mongodb" : "in-memory-demo" }));

app.get("/api/titles", async (req, res) => {
  try { res.json(await listTitles(String(req.query.q || "").slice(0, 100))); }
  catch { res.status(500).json({ message: "Could not load titles." }); }
});

app.get("/api/titles/:id", async (req, res) => {
  try {
    const title = mongoEnabled ? await Title.findById(req.params.id).lean() : demoTitles.find(t => t._id === req.params.id);
    if (!title) return res.status(404).json({ message: "Title not found." });
    res.json(title);
  } catch { res.status(400).json({ message: "Invalid title ID." }); }
});

app.post("/api/auth/register", async (req, res) => {
  try {
    const name = String(req.body.name || "").trim();
    const email = String(req.body.email || "").trim().toLowerCase();
    const password = String(req.body.password || "");
    if (name.length < 2 || !/^\S+@\S+\.\S+$/.test(email) || password.length < 8)
      return res.status(400).json({ message: "Enter a name, valid email, and password of at least 8 characters." });
    const passwordHash = await bcrypt.hash(password, 12);
    let user;
    if (mongoEnabled) {
      if (await User.findOne({ email })) return res.status(409).json({ message: "An account with this email already exists." });
      user = await User.create({ name, email, passwordHash });
    } else {
      if ([...demoUsers.values()].some(u => u.email === email)) return res.status(409).json({ message: "An account with this email already exists." });
      user = { id: `u${Date.now()}${Math.random().toString(16).slice(2)}`, name, email, passwordHash };
      demoUsers.set(user.id, user); demoWatchlists.set(user.id, []);
    }
    res.status(201).json({ token: signToken(user), user: safeUser(user) });
  } catch { res.status(500).json({ message: "Could not create account." }); }
});

app.post("/api/auth/login", async (req, res) => {
  try {
    const email = String(req.body.email || "").trim().toLowerCase();
    const password = String(req.body.password || "");
    const user = mongoEnabled ? await User.findOne({ email }) : [...demoUsers.values()].find(u => u.email === email);
    if (!user || !(await bcrypt.compare(password, user.passwordHash))) return res.status(401).json({ message: "Incorrect email or password." });
    res.json({ token: signToken(user), user: safeUser(user) });
  } catch { res.status(500).json({ message: "Could not log in." }); }
});

app.get("/api/watchlist", auth, async (req, res) => {
  try {
    const user = await getUser(req.user.id);
    if (!user && mongoEnabled) return res.status(404).json({ message: "Account not found." });
    const ids = mongoEnabled ? user.watchlist : (demoWatchlists.get(req.user.id) || []);
    const all = await listTitles();
    res.json(all.filter(t => ids.includes(String(t._id))));
  } catch { res.status(500).json({ message: "Could not load watchlist." }); }
});

app.post("/api/watchlist/:titleId", auth, async (req, res) => {
  try {
    const all = await listTitles();
    const title = all.find(t => String(t._id) === req.params.titleId);
    if (!title) return res.status(404).json({ message: "Title not found." });
    if (mongoEnabled) {
      const user = await getUser(req.user.id);
      if (!user) return res.status(404).json({ message: "Account not found." });
      if (!user.watchlist.includes(req.params.titleId)) user.watchlist.push(req.params.titleId);
      await user.save();
    } else {
      const ids = demoWatchlists.get(req.user.id);
      if (!ids) return res.status(404).json({ message: "Account not found." });
      if (!ids.includes(req.params.titleId)) ids.push(req.params.titleId);
    }
    res.json({ message: "Added to watchlist." });
  } catch { res.status(500).json({ message: "Could not update watchlist." }); }
});

app.delete("/api/watchlist/:titleId", auth, async (req, res) => {
  try {
    if (mongoEnabled) {
      const user = await getUser(req.user.id);
      if (!user) return res.status(404).json({ message: "Account not found." });
      user.watchlist = user.watchlist.filter(id => id !== req.params.titleId);
      await user.save();
    } else {
      const ids = demoWatchlists.get(req.user.id);
      if (!ids) return res.status(404).json({ message: "Account not found." });
      demoWatchlists.set(req.user.id, ids.filter(id => id !== req.params.titleId));
    }
    res.json({ message: "Removed from watchlist." });
  } catch { res.status(500).json({ message: "Could not update watchlist." }); }
});

async function start() {
  if (mongoEnabled) {
    await mongoose.connect(process.env.MONGODB_URI);
    await Title.bulkWrite(seedTitles.map(({ _id, ...doc }) => ({
      updateOne: { filter: { title: doc.title }, update: { $setOnInsert: doc }, upsert: true }
    })));
    console.log("Connected to MongoDB");
  }
  app.listen(PORT, () => console.log(`StreamFlix API listening on http://localhost:${PORT}`));
}
start().catch(err => { console.error("Server startup failed:", err.message); process.exit(1); });
