import mongoose from "mongoose";

export const User = mongoose.model("User", new mongoose.Schema({
  name: { type: String, required: true, trim: true, maxlength: 80 },
  email: { type: String, required: true, unique: true, lowercase: true, trim: true },
  passwordHash: { type: String, required: true },
  watchlist: { type: [String], default: [] }
}, { timestamps: true }));

export const Title = mongoose.model("Title", new mongoose.Schema({
  title: { type: String, required: true },
  genre: String, year: Number, rating: String, description: String, poster: String, featured: Boolean
}, { timestamps: true }));
