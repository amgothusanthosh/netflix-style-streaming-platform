import { useEffect, useMemo, useState } from "react";
import { Search, Play, Plus, Check, X, LogIn, LogOut, Film, Bookmark } from "lucide-react";

const API = import.meta.env.VITE_API_URL || "http://localhost:5000/api";
const demoTitles = [
  { _id:"t1", title:"The Last Signal", genre:"Sci-Fi", year:2025, rating:"13+", description:"A radio astronomer detects a signal that changes humanity's view of the stars.", poster:"https://images.unsplash.com/photo-1446776811953-b23d57bd21aa?w=800", featured:true },
  { _id:"t2", title:"City of Echoes", genre:"Thriller", year:2024, rating:"16+", description:"A journalist follows a trail of anonymous recordings through a sleepless city.", poster:"https://images.unsplash.com/photo-1519608487953-e999c86e7455?w=800", featured:true },
  { _id:"t3", title:"Beyond the Blue", genre:"Adventure", year:2023, rating:"7+", description:"A small crew sets out to map an uncharted ocean trench.", poster:"https://images.unsplash.com/photo-1518837695005-2083093ee35b?w=800" },
  { _id:"t4", title:"Paper Kingdom", genre:"Drama", year:2022, rating:"13+", description:"Two siblings restore their family's old bookshop and rediscover a forgotten story.", poster:"https://images.unsplash.com/photo-1507842217343-583bb7270b66?w=800" },
  { _id:"t5", title:"Orbit Zero", genre:"Sci-Fi", year:2025, rating:"13+", description:"An engineer must repair a failing orbital station before sunrise.", poster:"https://images.unsplash.com/photo-1451187580459-43490279c0fa?w=800" },
  { _id:"t6", title:"Sunday Kitchen", genre:"Comedy", year:2021, rating:"7+", description:"A chaotic family restaurant learns that the best recipe is teamwork.", poster:"https://images.unsplash.com/photo-1555939594-58d7cb561ad1?w=800" },
  { _id:"t7", title:"Wild North", genre:"Documentary", year:2024, rating:"7+", description:"A nature crew spends one season tracking wildlife across the northern wilderness.", poster:"https://images.unsplash.com/photo-1472396961693-142e6e269027?w=800" },
  { _id:"t8", title:"The Final Lap", genre:"Sports", year:2023, rating:"7+", description:"An underdog racing team fights to qualify for the championship.", poster:"https://images.unsplash.com/photo-1503735396912-9f4f2f0f6f1d?w=800" }
];

export default function App() {
  const [titles, setTitles] = useState(demoTitles);
  const [query, setQuery] = useState("");
  const [user, setUser] = useState(() => JSON.parse(localStorage.getItem("sf-user") || "null"));
  const [token, setToken] = useState(() => localStorage.getItem("sf-token") || "");
  const [watchlist, setWatchlist] = useState([]);
  const [onlyWatchlist, setOnlyWatchlist] = useState(false);
  const [modal, setModal] = useState(null);
  const [selected, setSelected] = useState(null);
  const [notice, setNotice] = useState("");
  const [busy, setBusy] = useState(false);
  const [apiOnline, setApiOnline] = useState(false);

  async function api(path, options = {}) {
    const response = await fetch(`${API}${path}`, {
      ...options, headers: { "Content-Type":"application/json", ...(token ? { Authorization:`Bearer ${token}` } : {}), ...options.headers }
    });
    const data = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(data.message || "Request failed");
    return data;
  }
  useEffect(() => {
    api("/health").then(() => setApiOnline(true)).catch(() => setApiOnline(false));
  }, []);
  useEffect(() => {
    if (!apiOnline) return;
    api(`/titles?q=${encodeURIComponent(query)}`).then(setTitles).catch(() => {});
  }, [query, apiOnline]);
  useEffect(() => {
    if (token && apiOnline) api("/watchlist").then(setWatchlist).catch(() => setWatchlist([]));
    else setWatchlist([]);
  }, [token, apiOnline]);

  const shown = useMemo(() => {
    let list = titles;
    if (!apiOnline && query.trim()) {
      const q = query.toLowerCase();
      list = list.filter(t => [t.title,t.genre,t.description].some(x => x?.toLowerCase().includes(q)));
    }
    return onlyWatchlist ? list.filter(t => watchlist.some(w => w._id === t._id)) : list;
  }, [titles, query, onlyWatchlist, watchlist, apiOnline]);
  const featured = titles.find(t => t.featured) || titles[0];

  async function submitAuth(e) {
    e.preventDefault(); setBusy(true); setNotice("");
    const form = new FormData(e.currentTarget);
    const body = Object.fromEntries(form.entries());
    try {
      if (!apiOnline) throw new Error("Start the backend server first (see README).");
      const data = await api(`/auth/${modal}`, { method:"POST", body:JSON.stringify(body) });
      setToken(data.token); setUser(data.user);
      localStorage.setItem("sf-token", data.token); localStorage.setItem("sf-user", JSON.stringify(data.user));
      setModal(null); setNotice(`Welcome${data.user.name ? `, ${data.user.name}` : ""}!`);
    } catch (err) { setNotice(err.message); }
    finally { setBusy(false); }
  }
  async function toggleWatch(title) {
    if (!token) { setModal("login"); setNotice("Log in to save titles to your watchlist."); return; }
    try {
      if (watchlist.some(t => t._id === title._id)) {
        await api(`/watchlist/${title._id}`, { method:"DELETE" });
        setWatchlist(prev => prev.filter(t => t._id !== title._id));
      } else {
        await api(`/watchlist/${title._id}`, { method:"POST" });
        setWatchlist(prev => [...prev, title]);
      }
    } catch (err) { setNotice(err.message); }
  }
  function logout() {
    setToken(""); setUser(null); setWatchlist([]);
    localStorage.removeItem("sf-token"); localStorage.removeItem("sf-user");
    setNotice("You have logged out.");
  }

  return <div className="app">
    <header className="nav">
      <a className="brand" href="#" onClick={() => {setOnlyWatchlist(false);setQuery("");}}><Film size={25}/> STREAMFLIX</a>
      <nav><button className={!onlyWatchlist ? "nav-link active" : "nav-link"} onClick={() => setOnlyWatchlist(false)}>Home</button><button className={onlyWatchlist ? "nav-link active" : "nav-link"} onClick={() => setOnlyWatchlist(true)}>My List</button></nav>
      <div className="nav-actions"><label className="search"><Search size={17}/><input value={query} onChange={e=>setQuery(e.target.value)} placeholder="Search titles"/></label>
      {user ? <button className="account" onClick={logout}><LogOut size={16}/><span>{user.name}</span></button> : <button className="sign-in" onClick={() => setModal("login")}><LogIn size={16}/> Sign in</button>}</div>
    </header>

    {featured && !onlyWatchlist && !query && <section className="hero" style={{backgroundImage:`linear-gradient(90deg,rgba(10,10,10,.96) 0%,rgba(10,10,10,.62) 48%,rgba(10,10,10,.12) 100%),linear-gradient(0deg,#101010 0%,transparent 48%),url("${featured.poster}")`}}>
      <div className="hero-copy"><span className="eyebrow">STREAMFLIX ORIGINAL · FEATURED</span><h1>{featured.title}</h1><p className="meta">{featured.year} <span>{featured.rating}</span> {featured.genre}</p><p className="description">{featured.description}</p>
      <div className="hero-buttons"><button className="play-btn" onClick={() => {setSelected(featured);setModal("details");}}><Play size={18} fill="currentColor"/> Explore title</button><button className="more-btn" onClick={() => toggleWatch(featured)}>{watchlist.some(t=>t._id===featured._id)?<Check size={18}/>:<Plus size={18}/>} My List</button></div>
      </div>
    </section>}

    <main className="content">
      <div className="section-heading"><div><h2>{onlyWatchlist ? "My List" : query ? `Search results for “${query}”` : "Popular on StreamFlix"}</h2><p>{shown.length} titles to discover</p></div><span className={apiOnline?"status online":"status"}>{apiOnline?"API connected":"Offline preview"}</span></div>
      {shown.length ? <div className="grid">{shown.map(t => <article className="movie" key={t._id}>
        <button className="poster" onClick={() => {setSelected(t);setModal("details");}} style={{backgroundImage:`url("${t.poster}")`}} aria-label={`View ${t.title}`}><span className="poster-play"><Play fill="currentColor" size={20}/></span><span className="poster-rating">{t.rating}</span></button>
        <div className="movie-info"><div><h3>{t.title}</h3><p>{t.year} · {t.genre}</p></div><button className="round" onClick={() => toggleWatch(t)} title="Add or remove from My List">{watchlist.some(w=>w._id===t._id)?<Check size={17}/>:<Plus size={17}/>}</button></div>
      </article>)}</div> : <div className="empty"><Bookmark size={32}/><h3>{onlyWatchlist?"Your list is empty":"No titles found"}</h3><p>{onlyWatchlist?"Add titles with the + button to save them here.":"Try a different search term."}</p></div>}
    </main>
    <footer><span className="brand small"><Film size={18}/> STREAMFLIX</span><span>Demo streaming catalogue · Built with React and Express</span><span>For portfolio and learning purposes</span></footer>

    {notice && <div className="toast" role="status">{notice}<button onClick={()=>setNotice("")} aria-label="Dismiss"><X size={16}/></button></div>}
    {modal && modal !== "details" && <div className="overlay" onClick={() => setModal(null)}><div className="auth-modal" onClick={e=>e.stopPropagation()}><button className="close" onClick={()=>setModal(null)}><X/></button><span className="brand"><Film size={24}/> STREAMFLIX</span><h2>{modal==="register"?"Create your account":"Welcome back"}</h2><p>{modal==="register"?"Save your favourite titles in one place.":"Sign in to access your personal watchlist."}</p>
      <form onSubmit={submitAuth}>{modal==="register"&&<input name="name" placeholder="Full name" minLength="2" required/>}<input type="email" name="email" placeholder="Email address" required/><input type="password" name="password" placeholder="Password (8+ characters)" minLength="8" required/><button className="submit" disabled={busy}>{busy?"Please wait…":modal==="register"?"Create account":"Sign in"}</button></form>
      <p className="switch">{modal==="register"?"Already have an account?":"New to StreamFlix?"} <button onClick={()=>setModal(modal==="register"?"login":"register")}>{modal==="register"?"Sign in":"Create an account"}</button></p>
    </div></div>}
    {modal==="details" && selected && <div className="overlay" onClick={()=>setModal(null)}><div className="detail-modal" onClick={e=>e.stopPropagation()}><div className="detail-image" style={{backgroundImage:`linear-gradient(0deg,#181818,transparent),url("${selected.poster}")`}}/><button className="close" onClick={()=>setModal(null)}><X/></button><div className="detail-copy"><span className="eyebrow">STREAMFLIX TITLE</span><h2>{selected.title}</h2><p className="meta">{selected.year} <span>{selected.rating}</span> {selected.genre}</p><p>{selected.description}</p><button className="more-btn" onClick={()=>toggleWatch(selected)}>{watchlist.some(w=>w._id===selected._id)?<Check size={18}/>:<Plus size={18}/>} {watchlist.some(w=>w._id===selected._id)?"Added to My List":"Add to My List"}</button></div></div></div>}
  </div>;
}
